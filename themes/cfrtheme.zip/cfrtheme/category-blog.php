<?php

/*
Template Name: Blog
*/
?>

<?php get_header();?>

<?php get_template_part( "includes/section", "archive" );?>

<?php get_footer();?>
