<?php

/*
Template Name: Contact Us
*/
?>

<?php get_header();?>

<section></section>
<?php get_template_part( "includes/section", "contact-us" );?>
<?php get_template_part( "includes/section", "contact-form" );?>

<?php get_footer();?>
