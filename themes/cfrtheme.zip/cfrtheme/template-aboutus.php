<?php

/*
Template Name: About Us
*/
?>

<?php get_header();?>

<section></section>
<?php get_template_part( "includes/section", "about-cfr" );?>
<?php get_template_part( "includes/section", "meet-the-team" );?>
<?php get_template_part( "includes/section", "cfr-metrics" );?>
<?php get_template_part( "includes/section", "cards" );?>
<?php get_template_part( "includes/section", "our-story" );?>
<section></section>
<?php get_template_part( "includes/section", "faqs" );?>
<?php get_template_part( "includes/section", "instawall" );?>

<?php get_footer();?>
