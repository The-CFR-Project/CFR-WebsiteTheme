<?php get_header();?>

<?php get_template_part( "includes/section", "blogcontent" );?>

<?php get_footer();?>