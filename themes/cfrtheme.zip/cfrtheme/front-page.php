<?php get_header();?>

<?php get_template_part( "includes/section", "home-banner" );?>
<?php get_template_part( "includes/section", "flight-calculator-preview" );?>
<?php get_template_part( "includes/section", "cards" );?>
<?php get_template_part( "includes/section", "faqs" );?>
<?php get_template_part( "includes/section", "instawall" );?>

<?php get_footer();?>
